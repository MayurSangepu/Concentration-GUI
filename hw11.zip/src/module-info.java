module ConcentrationGUI {
    requires transitive javafx.controls;
    exports view;
}